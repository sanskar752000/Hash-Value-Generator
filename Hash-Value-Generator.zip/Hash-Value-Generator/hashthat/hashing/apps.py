from django.apps import AppConfig


class HashingConfig(AppConfig):
    name = 'hashing'
