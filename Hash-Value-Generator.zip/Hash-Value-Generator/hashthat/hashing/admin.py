from django.contrib import admin
from .models import Hash

# Register your models here.
admin.site.register(Hash)